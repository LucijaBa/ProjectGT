<template>
  <div class="about">
    <h1>naziv treninga</h1>
    <div>
        <p>broj sudionika: </p> <!--dohvati iz baze -->
        <p>opis: </p> <!--dohvati iz baze -->
        <button>spremi</button> 
        <button>obrisi</button><br>
         Termini:
        <ul>
            <li></li>
        </ul>
    </div>
  </div>
</template>
