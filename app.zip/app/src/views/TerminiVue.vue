<template>
  <div class="about">
    <h1>termin</h1>
  </div>
</template>

<script>

    
</script>
